readme:

While implementing this assignment,

	1. Sudoku algorithm:
 		Runs properly and finds viable solutions
		I was unable to figure out how to pass the number of assignments and nodes stored in memory into my main program so for the purposes of answering the questions i had printed them to the console but have commented them out for the purpose of submission.

	2. Schedule courses algorithm:
		I was able to run it before but made a slight change which i was unable to figure out which causes it to through a keyError meaning that the key is not mapped to anything. However, the implemention I created I believe was correct and following the correct understanding of the problem although I did have some trouble figuring out how to set the constraints.

	3. Road Map algorithm:
		Implements and creates the graph that adds connection from node to node with the right distance but was unable to figure out how to call the graphProblem functions on this problem to pass in the arguments to A* so does not print anything. 